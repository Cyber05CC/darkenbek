document.addEventListener('keydown', (e) => {
    if (
        (e.ctrlKey && e.shiftKey && e.key === 'I') ||
        (e.ctrlKey && e.shiftKey && e.key === 'J') ||
        (e.ctrlKey && e.key === 'F12') ||
        e.key === 'F12'
    ) {
        e.preventDefault();
        e.stopImmediatePropagation();
        return false;
    }
});

document.addEventListener('DOMContentLoaded', async function () {
    ('use strict');

    const API_BASE = 'https://darkpanel-backend-swart.vercel.app/api';
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    // -------------------- CEP GUARD --------------------
    let csInterface = null;
    try {
        csInterface = new CSInterface();
    } catch (_) {
        console.warn('CSInterface not available. Running in browser preview mode.');
    }

    // -------------------- DEVICE ID --------------------
    async function getDeviceId() {
        try {
            if (csInterface) {
                const p = csInterface.getSystemPath(SystemPath.USER_DATA);
                if (p) return 'cep_' + String(p);
            }
        } catch (_) {}
        const ua = (navigator.userAgent || '') + (navigator.platform || '');
        const dims = (screen.width || 0) + 'x' + (screen.height || 0);
        return 'web_' + btoa(ua + '|' + dims);
    }
    const deviceId = await getDeviceId();

    // -------------------- API HELPERS --------------------
    async function apiPost(path, body) {
        try {
            const res = await fetch(`${API_BASE}${path}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body || {}),
                cache: 'no-store',
            });
            const data = await res.json().catch(() => ({}));
            return { ok: res.ok, data };
        } catch (err) {
            console.error('API error:', err);
            return { ok: false, data: { error: 'network_error' } };
        }
    }

    // -------------------- LICENSE SYSTEM --------------------
    const LOCAL_KEY = 'darkpanel_license_key';
    const LICENSE_CACHE = 'darkpanel_license_cache';

    async function checkKey(key) {
        const { data } = await apiPost('/license/check', { key, deviceId });
        // ✅ serverdan OK kelsa cache’ga yozib qo’yamiz
        if (data?.valid || data?.ok) {
            localStorage.setItem(
                LICENSE_CACHE,
                JSON.stringify({
                    ts: Date.now(),
                    type: data.type || (data.valid ? 'trial' : undefined),
                    expiresAt: data.expiresAt || null,
                })
            );
        }
        return data;
    }

    async function activateKey(key) {
        const { data } = await apiPost('/license/activate', { key, deviceId });
        return data;
    }

    //   function readLicenseCache() {
    //     try {
    //       return JSON.parse(localStorage.getItem(LICENSE_CACHE) || '{}');
    //     } catch (_) {
    //       return {};
    //     }
    //   }

    async function validateStoredKey() {
        const key = localStorage.getItem(LOCAL_KEY);
        if (!key) return false;

        if (!navigator.onLine) return true;

        const data = await checkKey(key);
        return !!(data && (data.ok === true || data.valid === true));
    }

    // -------------------- LICENSE STATUS DISPLAY --------------------
    // await renderKeyStatus();

    async function renderKeyStatus() {
        const key = localStorage.getItem(LOCAL_KEY);
        if (!key) return;
        const data = await checkKey(key);
        if (!data) return;

        const el = document.createElement('div');
        el.id = 'key-status';
        el.style.cssText = `
      position: fixed; bottom: 14px; left: 14px;
      background: rgba(22,22,24,0.7); border: 1px solid #2a2a2a;
      color: #ccc; font-family: Inter, system-ui, sans-serif;
      font-size: 12px; padding: 6px 10px; border-radius: 8px;
      backdrop-filter: blur(6px); z-index: 99999;
    `;

        if (data.ok && data.type === 'lifetime') {
            el.textContent = '💎';
            el.style.color = '#6df76d';
        } else if (data.ok && data.type === 'trial') {
            const days = Number(data.remainingDays ?? 0);
            if (days <= 0) {
                el.textContent = '❌ Trial expired';
                el.style.color = '#ff5e5e';
            } else {
                el.textContent = `⏳ Trial: ${days} day${days > 1 ? 's' : ''} left`;
                if (days <= 2) el.style.color = '#f5b400';
            }
        } else {
            el.textContent = '⚠️ Activation required';
            el.style.color = '#ffb400';
        }
        document.body.appendChild(el);
    }

    // -------------------- ACTIVATION UI --------------------
    function renderActivationUI() {
        if (!navigator.onLine) {
            showOfflineNeedsNetOverlay();
            return;
        }
        const overlay = document.createElement('div');
        overlay.id = 'dp-activation';
        overlay.style.cssText = `
      position:fixed;inset:0;background:#0f0f10;display:flex;
      align-items:center;justify-content:center;z-index:999999;color:#fff;
      font-family:Inter,system-ui,Arial,sans-serif;
    `;
        overlay.innerHTML = `
      <div style="width:min(420px,90vw);padding:22px 20px;border:1px solid #2a2a2a;
      border-radius:14px;background:linear-gradient(180deg,#141416,#0f0f10)">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
              <div style="width:32px;height:32px;border-radius:8px;background:#3537ff;
              display:flex;align-items:center;justify-content:center;">🔐</div>
              <h2 style="margin:0;font-size:18px;font-weight:700">darkPanel Activation</h2>
          </div>
          <p style="margin:6px 0 14px;color:#bdbdbd;font-size:12px">Please enter your key.</p>
          <input id="dp-key" placeholder="XXXX-XXXX-XXXX" spellcheck="false"
                 style="width:100%;padding:10px 12px;border-radius:10px;border:1px solid #2b2b2b;
                 background:#131318;color:#eaeaea;outline:none;font-size:13px">
          <div style="display:flex;gap:10px;margin-top:12px">
              <button id="dp-activate" style="flex:1;padding:10px 12px;border:0;
              border-radius:10px;background:#4a6cff;color:#fff;font-weight:600;cursor:pointer">
                  Activate
              </button>
              <button id="dp-exit" style="padding:0px 0px;border:0px solid #2b2b2b;
              border-radius:10px;background:#16161a;color:#ddd;cursor:pointer"></button>
          </div>
          <div id="dp-msg" style="margin-top:10px;color:#9ca3af;font-size:12px;min-height:16px"></div>
      </div>
    `;
        document.body.appendChild(overlay);

        document.getElementById('dp-exit').onclick = () => {
            document.getElementById('dp-msg').textContent = 'Activation required to continue.';
        };

        document.getElementById('dp-activate').onclick = async () => {
            const el = document.getElementById('dp-key');
            const msg = document.getElementById('dp-msg');
            const key = (el.value || '').trim().toUpperCase();
            if (!key) return (msg.textContent = 'Please paste your key.');

            msg.textContent = '🔄 Checking key…';

            const result = await activateKey(key);
            console.log('Activation result:', result);

            if (!result) {
                msg.textContent = '❌ No response from server.';
                return;
            }

            if (!result.ok) {
                const reason = result.error || 'Invalid key.';
                if (reason === 'bound_to_other_device')
                    msg.textContent = '⚠️ Key already used on another device.';
                else if (reason === 'trial_expired') msg.textContent = '⏰ Trial expired.';
                else if (reason === 'not_found') msg.textContent = '❌ Key not found.';
                else msg.textContent = '❌ ' + reason;
                return;
            }

            localStorage.setItem(LOCAL_KEY, key);
            msg.textContent = '✅ Activated successfully!';
            await sleep(700);
            overlay.remove();
            startApp();
        };
    }

    // -------------------- VALIDATION --------------------
    const hasKey = !!localStorage.getItem(LOCAL_KEY);

    if (!navigator.onLine) {
        if (hasKey) {
            // ✅ Offline + key bor → to‘g‘ridan to‘g‘ri UI
            showOfflineRibbon(); // kichik banner
            startApp();
        } else {
            // ❌ Offline + key yo‘q → aktivatsiya qilish uchun internet kerak
            showOfflineNeedsNetOverlay();
        }
        return; // bu holatlarda serverga so‘rov yo‘q
    }

    const valid = await validateStoredKey();
    if (!valid) {
        renderActivationUI(); // faqat online va key noto‘g‘ri bo‘lsa ochiladi
        return;
    }

    function showOfflineRibbon() {
        if (document.getElementById('offline-ribbon')) return;
        const bar = document.createElement('div');
        bar.id = 'offline-ribbon';
        bar.style.cssText = `
    position:fixed;left:12px;right:12px;bottom:10rem;z-index:99999;
    background:#191a1f;border:1px solid #2b2b2b;color:#bbb;
    padding:6px 10px;border-radius:8px;font:12px/1.2 Inter,system-ui;text-align:center;
  `;
        bar.textContent = '📡 Offline mode — some features need internet';
        document.body.appendChild(bar);
        window.addEventListener(
            'online',
            () => {
                bar.remove();
                location.reload();
            },
            { once: true }
        );
    }

    function showOfflineNeedsNetOverlay() {
        const el = document.createElement('div');
        el.style.cssText = `
    position:fixed;inset:0;display:flex;align-items:center;justify-content:center;
    background:#0f0f10;color:#fff;z-index:999999;font-family:Inter,system-ui;flex-direction:column;gap:8px;
  `;
        el.innerHTML = `
    <div style="font-size:40px">📡</div>
    <div style="font-size:16px;font-weight:700">No internet</div>
    <div style="font-size:13px;color:#bdbdbd">Activation requires internet connection</div>
    <button id="retryNet" style="margin-top:10px;padding:8px 14px;border-radius:10px;border:0;background:#4a6cff;color:#fff;font-weight:600">Try again</button>
  `;
        document.body.appendChild(el);
        const go = () => {
            el.remove();
            location.reload();
        };
        document.getElementById('retryNet').onclick = go;
        window.addEventListener('online', go, { once: true });
    }

    // -------------------- APP CORE --------------------
    startApp();

    // ========================
    // INFO MODAL SYSTEM
    // ========================
    const infoModal = document.getElementById('dp-info-modal');
    const infoPanel = infoModal?.querySelector('.info-panel');
    const closeInfoBtn = infoModal?.querySelector('.close-info');

    document.querySelector('.btn-wrapper').addEventListener('click', openInfoModal);
    closeInfoBtn.addEventListener('click', closeInfoModal);

    function openInfoModal() {
        infoModal.classList.add('show');

        // Animate first, load data later
        requestAnimationFrame(() => {
            setTimeout(() => {
                fillInfoModal();
            }, 120); // smooth delay
        });
    }

    function closeInfoModal() {
        infoModal.classList.remove('show');
    }

    // Close by clicking outside
    infoModal.addEventListener('click', (e) => {
        if (e.target === infoModal) {
            closeInfoModal();
        }
    });

    // Prevent close when clicking inside the panel
    infoPanel.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    // 🔁 Har safar panel ochilganda avtomatik ochilsin
    setTimeout(() => {
        if (infoModal) {
            openInfoModal();
        }
    }, 400);

    // ✨ Fill modal with REAL data from your JS
    async function fillInfoModal() {
        const key = localStorage.getItem(LOCAL_KEY);
        const statusEl = document.getElementById('modal-license-status');
        const trialEl = document.getElementById('modal-trial-days');
        const versionEl = document.getElementById('modal-version');
        const onlineEl = document.getElementById('modal-status');

        // Show instant skeleton state
        statusEl.textContent = 'Loading...';
        statusEl.style.color = '#bdbdbd';
        trialEl.textContent = '...';

        // online/offline
        if (navigator.onLine) {
            onlineEl.textContent = 'Online';
            onlineEl.classList.add('online');
            onlineEl.classList.remove('offline');
        } else {
            onlineEl.textContent = 'Offline';
            onlineEl.classList.add('offline');
            onlineEl.classList.remove('online');
        }

        // Fetch license in background without blocking UI
        checkKey(key).then((data) => {
            if (!data) {
                statusEl.textContent = 'Not Activated';
                statusEl.style.color = '#ff6f6f';
                trialEl.textContent = '–';
                return;
            }

            if (data.type === 'lifetime') {
                statusEl.textContent = 'Lifetime';
                statusEl.style.color = '#6df76d';
                trialEl.textContent = '∞';
            } else if (data.type === 'trial') {
                statusEl.textContent = 'Trial';
                statusEl.style.color = '#f5b400';
                trialEl.textContent = data.remainingDays ?? '0';
            }
        });

        // Version
        const version =
            localStorage.getItem('darkpanel_last_applied_version') ||
            localStorage.getItem('darkpanel_installed_version') ||
            '1.0';

        versionEl.textContent = 'v' + version;
    }

    window.addEventListener('online', () => {
        const s = document.getElementById('modal-status');
        if (s) {
            s.textContent = 'Online';
            s.style.color = '#00ff00ff';
        }
    });

    window.addEventListener('offline', () => {
        const s = document.getElementById('modal-status');
        if (s) {
            s.textContent = 'Offline';
            s.style.color = '#ff6f6f';
        }
    });

    async function startApp() {
        const GITHUB_RAW = 'https://raw.githubusercontent.com/Cyber05CC/darkpanel/main';
        const UPDATE_URL = API_BASE.replace('/api', '') + '/data/update.json';

        const LS_INSTALLED = 'darkpanel_installed_version';
        const LS_LAST_APPLIED = 'darkpanel_last_applied_version';

        const storedVersion =
            localStorage.getItem(LS_LAST_APPLIED) || localStorage.getItem(LS_INSTALLED);
        const BUNDLE_VERSION = storedVersion || '1.0';
        let currentVersion = BUNDLE_VERSION;

        const SUPPORTED_TEXT_FILES = [
            'index.html',
            'css/style.css',
            'js/main.js',
            'CSXS/manifest.xml',
        ];

        let selectedPreset = null;
        const autoPlayCheckbox = document.getElementById('autoPlay');
        const presetList = document.getElementById('presetList');
        const prevPageBtn = document.getElementById('prevPage');
        const nextPageBtn = document.getElementById('nextPage');
        const pageInfo = document.getElementById('pageInfo');
        const allTab = document.getElementById('allTab');
        const favoritesTab = document.getElementById('favoritesTab');
        const refreshBtn = document.getElementById('refresh');
        const applyBtn = document.getElementById('apply');
        const status = document.getElementById('status');
        const textPackBtn = document.getElementById('textPackBtn');
        const effectPackBtn = document.getElementById('effectPackBtn');

        const itemsPerPage = 10;
        let currentPage = 1;
        let totalPages = 1;
        let currentView = 'all';
        let currentPack = localStorage.getItem('currentPack') || 'text';
        let favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
        let presets = [];

        setupConnectionWatcher();

        // ⚡ YANGI: avtomatik update – popup yo'q, user hech narsa bosmaydi
        await autoUpdateIfNeeded();

        init();
        setupPackDropdown();

        // ================== PACK DROPDOWN SYSTEM ==================
        function setupPackDropdown() {
            const packDropdown = document.querySelector('.pack-dropdown');
            const packBtn = packDropdown?.querySelector('.pack-btn');
            const dropdownContent = packDropdown?.querySelector('.pack-dropdown-content');
            const labelSpan = packBtn?.querySelector('.pack-label');
            const arrowSpan = packBtn?.querySelector('.pack-arrow');

            if (!packBtn || !dropdownContent || !labelSpan || !arrowSpan) return;

            // 🔽 Pack tugmasi bosilganda dropdown + arrow toggle
            packBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isOpen = dropdownContent.classList.toggle('show');
                packBtn.classList.toggle('active', isOpen); // arrow rotate toggle
            });

            // 🔘 “Text” bosilganda
            textPackBtn.addEventListener('click', (e) => {
                e.preventDefault();
                dropdownContent.classList.remove('show');
                packBtn.classList.remove('active');
                switchPack('text');
            });

            // 🔘 “Effect” bosilganda
            effectPackBtn.addEventListener('click', (e) => {
                e.preventDefault();
                dropdownContent.classList.remove('show');
                packBtn.classList.remove('active');
                switchPack('effect');
            });

            // 🔥 Tashqariga bosilganda yopiladi
            document.addEventListener('click', (e) => {
                if (!packDropdown.contains(e.target)) {
                    dropdownContent.classList.remove('show');
                    packBtn.classList.remove('active');
                }
            });
        }

        // ======= BOUNCE UNDERLINE LOGIC =======
        const tabsContainer = document.querySelector('.tabs');
        const tabs = document.querySelectorAll('.tab');
        const underline = document.querySelector('.underline');

        if (tabsContainer && underline && tabs.length > 0) {
            function moveUnderline(el) {
                const rect = el.getBoundingClientRect();
                const parentRect = tabsContainer.getBoundingClientRect();

                const left = rect.left - parentRect.left;
                const width = rect.width;

                tabsContainer.style.setProperty('--underline-left', left + 'px');
                tabsContainer.style.setProperty('--underline-width', width + 'px');
            }

            // Start position
            const active = document.querySelector('.tab.active');
            if (active) moveUnderline(active);

            // Click listener
            tabs.forEach((tab) => {
                tab.addEventListener('click', () => {
                    document.querySelector('.tab.active')?.classList.remove('active');
                    tab.classList.add('active');
                    moveUnderline(tab);
                });
            });

            // Responsive update
            window.addEventListener('resize', () => {
                const activeTab = document.querySelector('.tab.active');
                if (activeTab) moveUnderline(activeTab);
            });
        }

        // ===================== INTERNET WATCHER =====================
        function setupConnectionWatcher() {
            function showConnectionAlert(message, type = 'error') {
                const existing = document.querySelector('.net-alert');
                if (existing) existing.remove();

                const alert = document.createElement('div');
                alert.className = `net-alert ${type}`;
                alert.innerHTML = `<span>${type === 'error' ? '📡' : '🌐'} ${message}</span>`;
                document.body.appendChild(alert);

                // animatsiya chiqish
                requestAnimationFrame(() => alert.classList.add('visible'));

                // avtomatik yashirish
                setTimeout(
                    () => {
                        alert.classList.remove('visible');
                        setTimeout(() => alert.remove(), 400);
                    },
                    type === 'error' ? 3500 : 1800
                );
            }

            window.addEventListener('offline', () => {
                showConnectionAlert('Ofline.', 'error');
            });

            window.addEventListener('online', () => {
                showConnectionAlert('Online', 'success');
                setTimeout(() => location.reload(true), 1000);
            });

            if (!navigator.onLine) showConnectionAlert('Ofline.', 'error');
        }

        // ===================== AUTO UPDATE SYSTEM =====================
        async function autoUpdateIfNeeded() {
            if (!navigator.onLine) {
                console.log('🔄 Offline – update skip');
                return;
            }

            try {
                const res = await fetch(UPDATE_URL + '?v=' + Date.now(), {
                    cache: 'no-store',
                });
                if (!res.ok) throw new Error('update.json not found');

                const remote = await res.json();
                if (!remote?.version || !remote.files) {
                    console.log('No version or files in update.json');
                    return;
                }

                const installed =
                    localStorage.getItem(LS_LAST_APPLIED) ||
                    localStorage.getItem(LS_INSTALLED) ||
                    BUNDLE_VERSION;

                if (remote.version === installed) {
                    console.log('✅ darkPanel already on latest:', installed);
                    currentVersion = installed;
                    // updateVersionDisplay();
                    return;
                }

                console.log('⬆ darkPanel auto-update', installed, '→', remote.version);

                // cache bust uchun
                localStorage.setItem('darkpanel_cache_bust', String(Date.now()));

                let wrote = false;

                // 1) Asosiy usul: extension papkaga fayllarni yozish (AE ichida)
                if (csInterface) {
                    wrote = await tryWriteToExtension(remote.files);
                }

                if (wrote) {
                    // haqiqiy fayllar extension ichida yangilandi
                    localStorage.setItem(LS_INSTALLED, remote.version);
                    localStorage.setItem(LS_LAST_APPLIED, remote.version);
                    currentVersion = remote.version;
                    // updateVersionDisplay();

                    console.log('✅ Files written to extension, restarting panel…');
                    hardReloadExtension(); // panelni qayta ishga tushiradi
                    return; // bu yerdan keyin baribir qayta yuklanadi
                }

                console.warn('❗ tryWriteToExtension failed or csInterface yok – overlay fallback');

                // 2) Fallback – faqat UI overlay (browser preview yoki yozish ruxsati yo‘q bo‘lsa)
                await applyRemoteOverlay(remote.files, remote.version);
                localStorage.setItem(LS_LAST_APPLIED, remote.version);
                currentVersion = remote.version;
                // updateVersionDisplay();
                hardReloadUI(remote.version);
            } catch (e) {
                console.warn('❌ autoUpdateIfNeeded error:', e);
            }
        }

        async function tryWriteToExtension(files) {
            if (!csInterface) return false;
            const extRoot = csInterface.getSystemPath(SystemPath.EXTENSION);

            const ensureFoldersScript = (fullPath) => `
                (function() {
                    function ensureFolder(path) {
                        var parts = path.split(/[\\\\\\/]/);
                        var acc = parts.shift();
                        while (parts.length) {
                            acc += "/" + parts.shift();
                            var f = new Folder(acc);
                            if (!f.exists) { try { f.create(); } catch(e) { return "ERR:" + e; } }
                        }
                        return "OK";
                    }
                    return ensureFolder("${fullPath.replace(/"/g, '\\"')}");
                })();
            `;

            for (const [rel, info] of Object.entries(files || {})) {
                if (!SUPPORTED_TEXT_FILES.includes(rel)) continue;
                const url = info.url + '?v=' + Date.now();
                const text = await (await fetch(url, { cache: 'no-store' })).text();

                const dir = rel.split('/').slice(0, -1).join('/');
                if (dir) {
                    const targetDir = extRoot + '/' + dir;
                    const ok = await new Promise((resolve) => {
                        csInterface.evalScript(ensureFoldersScript(targetDir), (res) =>
                            resolve(res === 'OK')
                        );
                    });
                    if (!ok) return false;
                }

                const targetFile = `${extRoot}/${rel}`;
                const wrote = await writeFileInChunks(targetFile, text);
                if (!wrote) return false;
            }
            return true;
        }

        async function writeFileInChunks(targetFile, text) {
            if (!csInterface) return false;
            const chunkSize = 30000;
            const chunks = [];
            for (let i = 0; i < text.length; i += chunkSize) {
                chunks.push(text.substring(i, i + chunkSize));
            }

            let mode = 'w';
            for (const chunk of chunks) {
                const writeChunkScript = `
                    (function() {
                        try {
                            var f = new File("${targetFile.replace(/"/g, '\\"')}");
                            f.encoding = "UTF-8";
                            f.open("${mode}");
                            f.write(${JSON.stringify(chunk)});
                            f.close();
                            return "OK";
                        } catch(e) { return "ERR:" + e; }
                    })();
                `;
                const result = await new Promise((resolve) => {
                    csInterface.evalScript(writeChunkScript, (res) => resolve(res === 'OK'));
                });
                if (!result) return false;
                mode = 'a';
            }
            return true;
        }

        function bustAllAssets(scopeEl, version) {
            const bust = (url) => {
                if (!url) return url;
                const sep = url.includes('?') ? '&' : '?';
                return `${url}${sep}v=${encodeURIComponent(version)}&cb=${Date.now()}`;
            };

            // CSS <link>
            scopeEl.querySelectorAll('link[rel="stylesheet"]').forEach((link) => {
                const href = link.getAttribute('href');
                if (href) link.setAttribute('href', bust(href));
            });

            // JS <script>
            scopeEl.querySelectorAll('script[src]').forEach((script) => {
                const src = script.getAttribute('src');
                if (src) script.setAttribute('src', bust(src));
            });

            // IMG
            scopeEl.querySelectorAll('img').forEach((img) => {
                if (img.src) img.src = bust(img.src);
            });

            // VIDEO + sources
            scopeEl.querySelectorAll('video').forEach((vid) => {
                const src = vid.getAttribute('src');
                if (src) vid.setAttribute('src', bust(src));

                vid.querySelectorAll('source').forEach((s) => {
                    const ssrc = s.getAttribute('src');
                    if (ssrc) s.setAttribute('src', bust(ssrc));
                });

                try {
                    vid.load();
                } catch (_) {}
            });
        }

        function hardReloadExtension() {
            sessionStorage.clear();
            const keep = {
                favorites: localStorage.getItem('favorites'),
                currentPack: localStorage.getItem('currentPack'),
                gridCols: localStorage.getItem('gridCols'),
                installed: localStorage.getItem(LS_INSTALLED),
                lastApplied: localStorage.getItem(LS_LAST_APPLIED),
                license: localStorage.getItem(LOCAL_KEY),
            };
            localStorage.clear();
            if (keep.favorites) localStorage.setItem('favorites', keep.favorites);
            if (keep.currentPack) localStorage.setItem('currentPack', keep.currentPack);
            if (keep.gridCols) localStorage.setItem('gridCols', keep.gridCols);
            if (keep.installed) localStorage.setItem(LS_INSTALLED, keep.installed);
            if (keep.lastApplied) localStorage.setItem(LS_LAST_APPLIED, keep.lastApplied);
            if (keep.license) localStorage.setItem(LOCAL_KEY, keep.license);

            if (csInterface) {
                csInterface.evalScript(
                    `
                    (function(){
                        try {
                            var extPath = new File($.fileName).parent.fsName;
                            var indexFile = new File(extPath + "/index.html");
                            if(indexFile.exists){
                                app.scheduleTask('$.evalFile(\\'' + indexFile.fsName + '\\')', 0, false);
                            }
                            return "Panel restarted";
                        } catch(e){ return "Error: " + e; }
                    })();
                `,
                    (res) => console.log('🔁 Reload:', res)
                );
            }
            setTimeout(() => location.reload(true), 800);
        }

        function hardReloadUI(version) {
            setTimeout(() => location.reload(true), 300);
        }

        // ---------------------- UI LOGIKA -------------------------
        function init() {
            updatePackUI();
            createPresets();
            setupEventListeners();
            setupGridControl();
            if (status) status.textContent = 'No items selected';
            // updateVersionDisplay();
        }

        function updateVersionDisplay() {
            let versionEl = document.getElementById('version-display');
            if (!versionEl) {
                versionEl = document.createElement('div');
                versionEl.id = 'version-display';
                versionEl.style.position = 'absolute';
                versionEl.style.bottom = '10px';
                versionEl.style.right = '10px';
                versionEl.style.color = '#888';
                versionEl.style.fontSize = '12px';
                versionEl.style.opacity = '0.7';
                versionEl.style.pointerEvents = 'none';
                document.body.appendChild(versionEl);
            }
            const shown = localStorage.getItem(LS_LAST_APPLIED) || currentVersion || BUNDLE_VERSION;
            versionEl.textContent = `v${shown}`;
        }

        function updatePackUI() {
            const packBtn = document.querySelector('.pack-btn');
            if (!packBtn) return;

            const labelSpan = packBtn.querySelector('.pack-label');
            if (!labelSpan) return;

            if (currentPack === 'text') {
                labelSpan.textContent = 'Text Pack';
                textPackBtn?.classList.add('active');
                effectPackBtn?.classList.remove('active');
            } else {
                labelSpan.textContent = 'Effect Pack';
                effectPackBtn?.classList.add('active');
                textPackBtn?.classList.remove('active');
            }
        }

        async function createPresets() {
            if (!presetList) return;
            presetList.innerHTML = '';

            // 🔥 Avtomatik sonni aniqlash
            let presetCount = 0;
            try {
                const res = await fetch(`${GITHUB_RAW}/assets/videos/list.json?v=${Date.now()}`);
                if (res.ok) {
                    const data = await res.json();
                    presetCount = data[currentPack] || 0;
                } else {
                    presetCount = currentPack === 'text' ? 30 : 15; // fallback
                }
            } catch {
                presetCount = currentPack === 'text' ? 30 : 15;
            }

            const packType = currentPack === 'text' ? 'Text' : 'Effect';
            for (let i = 1; i <= presetCount; i++) {
                const preset = document.createElement('div');
                preset.className = 'preset';
                preset.dataset.file = `${currentPack}_${i}.ffx`;

                const videoSrc = `${GITHUB_RAW}/assets/videos/${currentPack}_${i}.mp4?v=${Date.now()}`;
                preset.innerHTML = `
      <div class="preset-thumb">
        <video muted loop playsinline preload="metadata">
          <source src="${videoSrc}" type="video/mp4" />
        </video>
        <input type="checkbox" class="favorite-check" data-file="${currentPack}_${i}.ffx">
      </div>
      <div class="preset-name">${packType} ${i}</div>
    `;
                presetList.appendChild(preset);
            }

            presets = document.querySelectorAll('.preset');
            initializeFavorites();
            setupVideoHover();
            setupPresetSelection();
            showPage(1);
        }

        function setupVideoHover() {
            presets.forEach((preset) => {
                const video = preset.querySelector('video');
                preset.addEventListener('mouseenter', () => {
                    if (!autoPlayCheckbox?.checked) {
                        try {
                            video.currentTime = 0;
                            video.play().catch(() => {});
                        } catch (_) {}
                    }
                });
                preset.addEventListener('mouseleave', () => {
                    if (!autoPlayCheckbox?.checked) {
                        try {
                            video.pause();
                            video.currentTime = 0;
                        } catch (_) {}
                    }
                });
            });
        }

        function initializeFavorites() {
            presets.forEach((preset) => {
                const file = preset.dataset.file;
                const checkbox = preset.querySelector('.favorite-check');
                if (!checkbox) return;
                checkbox.checked = favorites.includes(file);
                checkbox.addEventListener('change', function () {
                    toggleFavorite(file, this.checked);
                });
            });
        }

        function toggleFavorite(file, isFavorite) {
            if (isFavorite && !favorites.includes(file)) favorites.push(file);
            else if (!isFavorite) favorites = favorites.filter((f) => f !== file);
            localStorage.setItem('favorites', JSON.stringify(favorites));
            if (currentView === 'favorites') showPage(1);
        }

        function showPage(page) {
            const filtered = filterPresets();
            currentPage = page;
            totalPages = Math.ceil(filtered.length / itemsPerPage) || 1;
            presets.forEach((p) => (p.style.display = 'none'));
            filtered
                .slice((page - 1) * itemsPerPage, page * itemsPerPage)
                .forEach((p) => (p.style.display = 'block'));
            if (pageInfo) pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;
            if (prevPageBtn) prevPageBtn.disabled = currentPage === 1;
            if (nextPageBtn) nextPageBtn.disabled = currentPage === totalPages;
            manageVideos();
        }

        async function staggeredAutoPlay(videos) {
            let delay = 60; // ms navbat smooth

            for (let i = 0; i < videos.length; i++) {
                const vid = videos[i];
                if (!vid) continue;

                try {
                    vid.currentTime = 0;
                    await vid.play();
                    vid.playbackRate = 1.001; // 🔥 Chrome throttling FIX
                } catch (_) {}

                await new Promise((r) => setTimeout(r, delay));
            }
        }

        function manageVideos() {
            const filtered = filterPresets().slice(
                (currentPage - 1) * itemsPerPage,
                currentPage * itemsPerPage
            );

            const videos = filtered.map((p) => p.querySelector('video')).filter(Boolean);

            if (autoPlayCheckbox?.checked) {
                staggeredAutoPlay(videos);
            } else {
                videos.forEach((v) => {
                    try {
                        v.pause();
                        v.currentTime = 0;
                    } catch (_) {}
                });
            }
        }

        function filterPresets() {
            return Array.from(presets).filter(
                (preset) => currentView === 'all' || favorites.includes(preset.dataset.file)
            );
        }

        function setupPresetSelection() {
            presets.forEach((preset) => {
                preset.addEventListener('click', (e) => {
                    if (e.target.classList.contains('favorite-check')) return;
                    presets.forEach((p) => p.classList.remove('selected'));
                    preset.classList.add('selected');
                    selectedPreset = preset.dataset.file;
                    if (status)
                        status.textContent = `Selected: ${
                            preset.querySelector('.preset-name').textContent
                        }`;
                });
            });
        }

        function setupGridControl() {
            const gridButtons = document.querySelectorAll('.grid-btn');
            const presetsContainer = document.querySelector('.presets');

            if (!presetsContainer || gridButtons.length === 0) return;

            // --- USER CHOICE SAQLANADI ---
            let userSelectedCols = parseInt(localStorage.getItem('gridCols') || '2', 10);

            function applyGrid(cols, fromUser = false) {
                presetsContainer.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;

                if (fromUser) {
                    userSelectedCols = cols;
                    localStorage.setItem('gridCols', String(cols));
                }

                gridButtons.forEach((btn) =>
                    btn.classList.toggle('active', parseInt(btn.dataset.cols) === cols)
                );
            }

            // --- GRID BUTTON BOSILGANDA ---
            gridButtons.forEach((btn) => {
                btn.addEventListener('click', () => {
                    const cols = parseInt(btn.dataset.cols, 10);
                    applyGrid(cols, true);
                });
            });

            // --- RESPONSIVE AUTO-DETECT ---
            function autoDetectGrid() {
                const width = window.innerWidth;

                if (width <= 420) {
                    applyGrid(1);
                } else if (width <= 640) {
                    applyGrid(2);
                } else if (width <= 720) {
                    applyGrid(3);
                } else {
                    applyGrid(userSelectedCols); // user tanlagani
                }
            }

            // FIRST INIT
            autoDetectGrid();

            // WINDOW RESIZE
            window.addEventListener('resize', autoDetectGrid);
        }

        async function applyPreset() {
            if (!selectedPreset) {
                showCustomAlert('Choose a preset first!', false);
                return;
            }

            const remotePresetUrl = `${GITHUB_RAW}/presets/${selectedPreset}`;
            try {
                const res = await fetch(remotePresetUrl, { cache: 'no-store' });
                if (!res.ok) throw new Error('Preset not found');
                const blob = await res.blob();
                const base64 = await blobToBase64(blob);

                const chunkSize = 20000; // safe for evalScript payload
                const chunks = [];
                for (let i = 0; i < base64.length; i += chunkSize) {
                    chunks.push(base64.slice(i, i + chunkSize));
                }

                // 1) Create temp file once
                const openScript = `
                    (function() {
                        try {
                            var presetPath = Folder.temp.fsName + "/darkpanel_temp.ffx";
                            var f = new File(presetPath);
                            f.encoding = "BINARY";
                            if (!f.open("w")) return "Error: Cannot open file for writing";
                            f.close();
                            return presetPath;
                        } catch(e) { return "Error: " + e; }
                    })();
                `;
                const openResult = await new Promise((resolve) =>
                    csInterface
                        ? csInterface.evalScript(openScript, resolve)
                        : resolve('Error: CSInterface not available')
                );
                if (typeof openResult !== 'string' || openResult.indexOf('Error:') === 0) {
                    showCustomAlert(openResult || 'Error: Failed to create temp file', false);
                    return;
                }
                const presetPath = openResult;
                const escapedPresetPath = presetPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

                // 2) Append all chunks
                for (const chunk of chunks) {
                    const appendScript = `
                        (function() {
                            function b64decode(b64) {
                                var chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
                                var out="", buffer=0, bits=0, c;
                                for (var i=0;i<b64.length;i++){
                                    c=b64.charAt(i);
                                    if(c==='=')break;
                                    var idx=chars.indexOf(c);
                                    if(idx===-1)continue;
                                    buffer=(buffer<<6)|idx; bits+=6;
                                    if(bits>=8){bits-=8;out+=String.fromCharCode((buffer>>bits)&0xFF);}
                                }
                                return out;
                            }
                            try {
                                var f = new File("${escapedPresetPath}");
                                f.encoding = "BINARY";
                                if (!f.open("a")) return "Error: Cannot open file for append";
                                var bin = b64decode("${chunk}");
                                f.write(bin);
                                f.close();
                                return "OK";
                            } catch(e) { return "Error: " + e; }
                        })();
                    `;
                    const appendResult = await new Promise((resolve) =>
                        csInterface
                            ? csInterface.evalScript(appendScript, resolve)
                            : resolve('Error: CSInterface not available')
                    );
                    if (appendResult !== 'OK') {
                        showCustomAlert(appendResult || 'Error: write failed', false);
                        return;
                    }
                }

                // 3) Apply preset to selected layers
                const applyScript = `
                    (function() {
                        try {
                            var f = new File("${escapedPresetPath}");
                            if (!f.exists) return "Error: File not found";
                            var activeItem = app.project.activeItem;
                            if (!activeItem || !(activeItem instanceof CompItem)) return "Error: No active composition";
                            var selectedLayers = activeItem.selectedLayers;
                            if (selectedLayers.length === 0) return "Error: Please select at least one layer";
                            var successCount = 0;
                            for (var i = 0; i < selectedLayers.length; i++) {
                                selectedLayers[i].applyPreset(f);
                                successCount++;
                            }
                            try { f.remove(); } catch(_) {}
                            return "Success:" + successCount;
                        } catch(err) { return "Error: " + err.toString(); }
                    })();
                `;
                if (!csInterface) {
                    showCustomAlert('CSInterface not available (browser preview).', false);
                    return;
                }
                csInterface.evalScript(applyScript, (result) => {
                    if (result && result.indexOf('Success:') === 0) {
                        showCustomAlert(' ' + result.split(':')[1] + ' Applied to layer', true);
                    } else {
                        showCustomAlert(result || 'Unknown error', false);
                    }
                });
            } catch (err) {
                showCustomAlert('Error loading: ' + err.message, false);
            }
        }

        function blobToBase64(blob) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(String(reader.result).split(',')[1]);
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            });
        }

        function showCustomAlert(message, isSuccess) {
            const existing = document.querySelector('.custom-alert:not(.update)');
            if (existing) existing.remove();
            const videoPath = isSuccess
                ? `${GITHUB_RAW}/assets/videos/gojo.mp4?v=${encodeURIComponent(
                      localStorage.getItem(LS_LAST_APPLIED) || currentVersion
                  )}`
                : `${GITHUB_RAW}/assets/videos/social.mp4?v=${encodeURIComponent(
                      localStorage.getItem(LS_LAST_APPLIED) || currentVersion
                  )}`;
            const alertBox = document.createElement('div');
            alertBox.className = 'custom-alert';
            alertBox.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99998`;
            alertBox.innerHTML = `
                <div class="alert-content" style="background:#141416;border:1px solid #2b2b2b;border-radius:14px;padding:16px 14px;color:#eaeaea;min-width:260px;max-width:360px;">
                    <div class="alert-icon" style="margin-bottom:8px">
                        <video autoplay muted loop playsinline class="alert-video" style="width:100%;border-radius:10px;display:block">
                            <source src="${videoPath}&t=${Date.now()}" type="video/mp4" />
                        </video>
                    </div>
                    <div class="alert-message" style="font-weight:600;margin-bottom:10px">${message}</div>
                    <button class="alert-close" style="padding:8px 14px;border:0;border-radius:10px;background:#4a6cff;color:#fff;cursor:pointer;width:100%">OK</button>
                </div>`;
            document.body.appendChild(alertBox);
            requestAnimationFrame(() => alertBox.classList.add('visible'));
            alertBox.querySelector('.alert-close').onclick = () => {
                alertBox.classList.remove('visible');
                setTimeout(() => alertBox.remove(), 280);
            };
        }

        function setupEventListeners() {
            autoPlayCheckbox?.addEventListener('change', manageVideos);
            prevPageBtn?.addEventListener(
                'click',
                () => currentPage > 1 && showPage(currentPage - 1)
            );
            nextPageBtn?.addEventListener(
                'click',
                () => currentPage < totalPages && showPage(currentPage + 1)
            );
            refreshBtn?.addEventListener('click', () => {
                selectedPreset = null;
                presets.forEach((p) => p.classList.remove('selected'));
                if (status) status.textContent = 'No items selected';
                showPage(1);
            });
            applyBtn?.addEventListener('click', applyPreset);
            allTab?.addEventListener('click', () => switchTab('all'));
            favoritesTab?.addEventListener('click', () => switchTab('favorites'));
            textPackBtn?.addEventListener('click', (e) => {
                e.preventDefault();
                switchPack('text');
            });
            effectPackBtn?.addEventListener('click', (e) => {
                e.preventDefault();
                switchPack('effect');
            });
        }

        function switchPack(type) {
            if (currentPack === type) return;
            document.querySelectorAll('.preset video').forEach((v) => {
                try {
                    v.pause();
                    v.currentTime = 0;
                } catch (_) {}
            });
            currentPack = type;
            localStorage.setItem('currentPack', type);
            updatePackUI();
            createPresets();
            selectedPreset = null;
            if (status) status.textContent = 'No items selected';
        }

        function switchTab(type) {
            if (currentView === type) return;
            currentView = type;
            allTab?.classList.toggle('active', type === 'all');
            favoritesTab?.classList.toggle('active', type === 'favorites');
            selectedPreset = null;
            if (status) status.textContent = 'No items selected';
            showPage(1);
        }
    }
});
