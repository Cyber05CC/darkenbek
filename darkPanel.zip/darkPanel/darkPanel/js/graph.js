/**
 * Speed Graph Pro - High Precision AE Logic
 * Perfectly matched with Adobe After Effects Visuals
 */

const state = {
    influenceOut: 33.33,
    influenceIn: 33.33,
    paddingX: 60,
    paddingY: 70, // Increased top padding for better peak room
    width: 0,
    height: 0,
    isDragging: null,
};

// DOM Elements
const svg = document.getElementById('mainSvg');
const curvePath = document.getElementById('speedCurve');
const lineH1 = document.getElementById('lineH1');
const lineH2 = document.getElementById('lineH2');
const k1 = document.getElementById('k1');
const k2 = document.getElementById('k2');
const handle1 = document.getElementById('handle1');
const handle2 = document.getElementById('handle2');
const outInput = document.getElementById('outInput');
const inInput = document.getElementById('inInput');
const outValTxt = document.getElementById('outVal');
const inValTxt = document.getElementById('inVal');
const statsOverlay = document.getElementById('statsOverlay');
const applyBtn = document.getElementById('applyBtn');
const statusTxt = document.getElementById('status');

function init() {
    updateDimensions();
    render();

    window.addEventListener('resize', () => {
        updateDimensions();
        render();
    });

    outInput.addEventListener('input', (e) => {
        state.influenceOut = parseFloat(e.target.value);
        render();
    });
    inInput.addEventListener('input', (e) => {
        state.influenceIn = parseFloat(e.target.value);
        render();
    });

    handle1.addEventListener('mousedown', (e) => {
        e.preventDefault();
        state.isDragging = 0;
    });
    handle2.addEventListener('mousedown', (e) => {
        e.preventDefault();
        state.isDragging = 1;
    });

    window.addEventListener('mousemove', (e) => {
        if (state.isDragging === null) return;

        const rect = svg.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const innerWidth = state.width - state.paddingX * 2;
        const halfWidth = innerWidth / 2;

        if (state.isDragging === 0) {
            let dist = mouseX - state.paddingX;
            let inf = (dist / halfWidth) * 100;
            state.influenceOut = Math.max(0.1, Math.min(100, inf));
        } else {
            let dist = state.width - state.paddingX - mouseX;
            let inf = (dist / halfWidth) * 100;
            state.influenceIn = Math.max(0.1, Math.min(100, inf));
        }
        render();
    });

    window.addEventListener('mouseup', () => {
        state.isDragging = null;
    });

    document.querySelectorAll('.preset-btn').forEach((btn) => {
        btn.addEventListener('click', () => {
            applyPreset(btn.getAttribute('data-type'));
        });
    });

    // document.getElementById('resetBtn').addEventListener('click', () => applyPreset('ease'));
    applyBtn.addEventListener('click', applyToAE);

    drawGrid();
}

function updateDimensions() {
    const rect = svg.getBoundingClientRect();
    state.width = rect.width;
    state.height = rect.height;
}

function applyPreset(type) {
    switch (type) {
        case 'linear':
            state.influenceOut = 0.1;
            state.influenceIn = 0.1;
            break;
        case 'ease':
            state.influenceOut = 33.33;
            state.influenceIn = 33.33;
            break;
        case 'ease-in':
            state.influenceOut = 10;
            state.influenceIn = 75;
            break;
        case 'ease-out':
            state.influenceOut = 75;
            state.influenceIn = 10;
            break;
        case 'extreme':
            state.influenceOut = 100;
            state.influenceIn = 100;
            break;
    }
    render();
}

/**
 * AE Speed Graph Visualization Logic
 * We must map the velocity curve into our visual graph space.
 */
function calculateSpeedPath() {
    const w = state.width - state.paddingX * 2;
    const h = state.height - state.paddingY * 2;

    // AE influence is 0-1. In our UI, 100% influence is visually the middle (0.5)
    // To match AE's visual, we treat the influence as a direct factor for the curve shape.
    const h_out = state.influenceOut / 100;
    const h_in = state.influenceIn / 100;

    let d = '';
    const steps = 100;
    let points = [];
    let maxV = 0;

    for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const mt = 1 - t;

        // Correct derivative of AE's x(t) = 3(1-t)^2*t*h_out + 3(1-t)*t^2*(1-h_in) + t^3
        const dxdt = 3 * mt * mt * h_out + 6 * mt * t * (1 - h_in - h_out) + 3 * t * t * h_in;
        // Normalized speed y'(t) = 6t(1-t)
        const dydt = 6 * mt * t;

        const v = dxdt < 0.0001 ? 100 : dydt / dxdt;
        if (v > maxV) maxV = v;
        points.push({ t, v });
    }

    // In After Effects, 33% influence produces a peak height that we want to look "standard".
    // We normalize the visual height so that 33.33% / 33.33% looks like a perfect AE bell curve.
    // AE Peak velocity at 33.33% is approx 1.5.
    const standardPeak = 1.5;
    const visualScaleFactor = (h * 0.7) / standardPeak; // Scale so 1.5 speed takes 70% of height

    // We cap the extreme scale to prevent the spike from vanishing into infinity visually
    const currentMaxV = Math.max(0.1, maxV);
    const adaptiveScale = Math.min(visualScaleFactor, h / currentMaxV);

    for (let i = 0; i <= steps; i++) {
        const t = points[i].t;
        const mt = 1 - t;
        // x(t) position in the graph
        const x = (3 * mt * mt * t * h_out + 3 * mt * t * t * (1 - h_in) + t * t * t) * w;
        // y position (inverted SVG)
        const y = h - points[i].v * adaptiveScale;

        d += (i === 0 ? 'M ' : ' L ') + x.toFixed(2) + ',' + y.toFixed(2);
    }
    return d;
}

function render() {
    // UI Sync
    outInput.value = state.influenceOut;
    inInput.value = state.influenceIn;
    outValTxt.innerText = state.influenceOut.toFixed(1) + '%';
    inValTxt.innerText = state.influenceIn.toFixed(1) + '%';
    statsOverlay.innerText = `Influence: ${state.influenceOut.toFixed(
        1
    )} / ${state.influenceIn.toFixed(1)}`;

    const innerW = state.width - state.paddingX * 2;
    const halfW = innerW / 2;
    const baselineY = state.height - state.paddingY;

    // UI Visual: 100% influence meets in the middle
    const h1x = state.paddingX + halfW * (state.influenceOut / 100);
    const h2x = state.width - state.paddingX - halfW * (state.influenceIn / 100);

    // Update Path
    curvePath.setAttribute('d', calculateSpeedPath());
    curvePath.setAttribute('transform', `translate(${state.paddingX}, ${state.paddingY})`);

    // Dotted Lines
    lineH1.setAttribute('x1', state.paddingX);
    lineH1.setAttribute('y1', baselineY);
    lineH1.setAttribute('x2', h1x);
    lineH1.setAttribute('y2', baselineY);

    lineH2.setAttribute('x1', state.width - state.paddingX);
    lineH2.setAttribute('y1', baselineY);
    lineH2.setAttribute('x2', h2x);
    lineH2.setAttribute('y2', baselineY);

    // Keyframes
    k1.setAttribute('x', state.paddingX - 4);
    k1.setAttribute('y', baselineY - 4);
    k2.setAttribute('x', state.width - state.paddingX - 4);
    k2.setAttribute('y', baselineY - 4);

    // Handle Diamonds
    updateHandle(handle1, h1x, baselineY);
    updateHandle(handle2, h2x, baselineY);
}

function updateHandle(group, x, y) {
    const hit = group.querySelector('.hit-rect');
    const diamond = group.querySelector('.handle-diamond');
    hit.setAttribute('x', x - 15);
    hit.setAttribute('y', y - 15);
    diamond.setAttribute('x', x - 5);
    diamond.setAttribute('y', y - 5);
    diamond.setAttribute('transform', `rotate(45 ${x} ${y})`);
}

function drawGrid() {
    const grid = document.getElementById('grid');
    grid.innerHTML = '';
    const lines = 12;
    for (let i = 0; i <= lines; i++) {
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        const y = state.paddingY + (i * (state.height - state.paddingY * 2)) / lines;
        line.setAttribute('x1', 0);
        line.setAttribute('y1', y);
        line.setAttribute('x2', '100%');
        line.setAttribute('y2', y);
        line.classList.add('grid-line');
        grid.appendChild(line);
    }
}

function applyToAE() {
    if (!window.CSInterface) {
        statusTxt.innerText = 'STANDALONE PREVIEW';
        return;
    }
    const cs = new CSInterface();
    statusTxt.innerText = 'APPLYING...';

    const outVal = state.influenceOut.toFixed(4);
    const inVal = state.influenceIn.toFixed(4);

    cs.evalScript(`applySpeedGraph(${inVal}, ${outVal})`, function (res) {
        if (res.indexOf('ERROR') > -1) {
            statusTxt.style.color = '#f43f5e';
            statusTxt.innerText = res.replace('ERROR: ', '').toUpperCase();
        } else {
            statusTxt.style.color = '#10b981';
            statusTxt.innerText = 'SUCCESSFULLY APPLIED';
        }
        setTimeout(() => {
            statusTxt.style.color = '';
            statusTxt.innerText = 'READY';
        }, 2000);
    });
}

init();
